import configparser
import os
from sqlalchemy import create_engine
import bcrypt

def get_key_gepeto(tipo):
    config = configparser.ConfigParser()

    # Check if file exists
    if not os.path.exists('app.ini'):
        print("Configuration file app.ini not found.")
        return None
    
    try:
        config.read('app.ini')
        
        # Check if the section and key exist
        if 'API_KEY' in config and 'key_gepeto' in config['API_KEY']:
            if tipo == 'completo':
                key = config.get('API_KEY', 'key_gepeto')
                return key
            elif tipo == 'curto':
                key = config.get('API_KEY', 'key_gepeto2')
                return key
            else:
                print("Informou o tipo errado")
                return None
        else:
            print("Section 'API_KEY' or key 'key_gepeto' not found in app.ini.")
            return None
    except configparser.Error as e:
        print(f"An error occurred while reading the configuration file: {e}")
        return None
    
def create_connection():
    config = configparser.ConfigParser()
    if not os.path.exists('app.ini'):
        print("Configuration file app.ini not found.")
        return None
    try:
        config.read('app.ini')
        if 'BANCO' in config and 'string_banco' in config['BANCO']:
            banco = config.get('BANCO', 'string_banco')
            return create_engine(banco)
        else:
            print("Section 'BANCO' or key 'string_banco' not found in app.ini.")
            return None
    except configparser.Error as e:
        print(f"An error occurred while reading the configuration file: {e}")
        return None
    
def check_password(plain_text_password, hashed_password):
    return bcrypt.checkpw(plain_text_password.encode(), hashed_password)

def get_hashed_password(plain_text_password):
    return bcrypt.hashpw(plain_text_password.encode(), bcrypt.gensalt())