CREATE TABLE IF NOT EXISTS usuarios(
    id int AUTO_INCREMENT, 
    tipo enum('aluno', 'professor'),
    nome varchar(100) default '', 
    login varchar(100) NOT NULL UNIQUE,
    senha varchar(500) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS salas(
    id int AUTO_INCREMENT, 
    id_professor int NOT NULL,
    configSala JSON NOT NULL,
    PRIMARY KEY (id), 
    FOREIGN KEY(id_professor) REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS historico_conversa(
    id int AUTO_INCREMENT, 
    id_sala int NOT NULL,
    role VARCHAR(20) NOT NULL,
    id_usuario int NOT NULL,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    content varchar(500) NOT NULL,
    
    PRIMARY KEY (id), 
    FOREIGN KEY(id_sala) REFERENCES salas(id),
    FOREIGN KEY(id_usuario) REFERENCES usuarios(id)   
    
    );

engine.execute(""" insert into usuarios 
(tipo, nome, login, senha) 
values('professor', 'prof1','prof','$2b$12$lNqZLOzkOevhbid9BdRnmeJdWWpXwWu641AaI3eEKDQgbvq4s5J/G' )""")

engine.execute(""" insert into usuarios 
(tipo, nome, login, senha) 
values('aluno', 'aluno1','aluno','$2b$12$lNqZLOzkOevhbid9BdRnmeJdWWpXwWu641AaI3eEKDQgbvq4s5J/G' )""")

