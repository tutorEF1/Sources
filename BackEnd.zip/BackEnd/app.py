from flask import Flask, request, jsonify, g
from flask_cors import CORS
from flask_restx import Api, Resource, fields
import jwt
from functools import wraps
from basegpt import  chamadaGEPETO
from utils import create_connection, check_password
import pandas as pd
import functionsSalas as fs
import ChatTutor as ct
from sqlalchemy.exc import SQLAlchemyError



def create_app():
    app = Flask(__name__)
    cors = CORS(app, resources={r"/*": {"origins": "*"}})   
   
    app.config['SECRET_KEY'] = 'thisissecret'
    api = Api(app, version='1.0', title='DashBoard Custom', description='dashboard', doc='/docs/')      
    engine = create_connection()
    modelo_chamada = api.model('chamadaBase', {
        'pergunta': fields.String(description='Pergunta ao gpt'),
        })
    modelo_login = api.model('login', {
        'login':fields.String(description='Login do Usuario'),
        'senha':fields.String(description='Senha do Usuario')
        })
    modelo_sala = api.model('sala', {
        'nome':fields.String(description='Nome da Sala'),
        'area':fields.String(description='Area da Sala'),
        'assunto':fields.String(description='Assunto da Sala'),
        'caracteristica':fields.String(description='Caracteristicas dos alunos da Sala'),
        })
    
    def token_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            token = None
            
            if 'x-api-key' in request.headers:
                token = request.headers['x-api-key']
           
            if not token:
                return jsonify({'message' : 'Token is missing!'}), 401
    
            try: 
                data = jwt.decode(token, app.config['SECRET_KEY'],algorithms="HS256")
                current_user = pd.read_sql_query('''select * from usuarios
                                                 where login = '%s' '''
                                                 %(data['login']),con = engine)
                g.current_user = current_user
            except:
                return jsonify({'message' : 'Token is invalid!'}), 401
    
            return f(*args, **kwargs) 
        return decorated

    @api.route('/hello')   
    class HelloWorld(Resource):
        @token_required
        def get(self):            
            try:       
                current_user = g.current_user
                return {'TCC': current_user.to_dict()}
            except Exception as e:
                print('error', str(e))
                return ('error', str(e)),500
            
    @api.route('/chatbase')
    class ChatBase(Resource):
        @api.expect(modelo_chamada)
        def post(self):
            try:               
                
                data = request.get_json()
                
                pergunta = data.get('pergunta', '')
                resp = chamadaGEPETO(pergunta)
                return resp
            except Exception as e:
                print('error', str(e))
                return ('error', str(e)),500
            
    @api.route('/login')
    class Login(Resource):
        @api.expect(modelo_login)
        def post(self):
            try:
                engine = create_connection()
                
                args = request.get_json()
                
                login = args.get('login', '')
                if login != '':                
                    user = pd.read_sql_query(''' select * from usuarios 
                                          where login = '%s' '''%(login),con = engine)
                else:
                    return jsonify({'Erro1' : 'Nenhum login foi informado'})                    
                
                if user.empty :
                    return  jsonify({'Erro2' : 'Usuario não encontrado'})
                else:
                    senhaHash = user['senha'].iloc[0].encode()
                    
                    if not check_password(args['senha'], senhaHash):
                        return jsonify({'Erro3' : 'Senha Incorreta'})
                   
                token = jwt.encode({'login' :login}, app.config['SECRET_KEY'])
                
                user =  user.drop(['senha'], axis=1)      
                
                return jsonify({'token' : token, 'user_info':user.to_dict(orient='records')[0]})
        
            except Exception as e:
                print(f"Erro ao Logar: {str(e)}")
                return jsonify({'Erro4' : str(e)})
            finally:
                engine.dispose()
                
    @api.route('/criarSala')
    class CriarSala(Resource):
        
        @api.expect(modelo_sala)
        @token_required
        def post(self):
            engine = None
            try:
                engine = create_connection()
                args = request.get_json()
                current_user = g.current_user
                
                print(args)
                if not self.is_professor(current_user):
                    return {'message': 'Acesso não autorizado'}, 403
                
                user_id = current_user.id.iloc[0]
                retorno, status_code = fs.CriarSala(user_id, args, engine)
                
                return retorno, status_code  # Retorno e código de status
            
            except Exception as e:
                print(f"Erro ao criar sala: {str(e)}")
                return {'message': 'Erro interno do servidor'}, 500
            
            finally:
                if engine:
                    engine.dispose()
    
        def is_professor(self, user):
            return user.tipo.iloc[0] == 'professor'
        
    @api.route('/returnSalas')
    class returnSalas(Resource):
        
        @token_required
        def get(self):
            engine = None
            try:
                engine = create_connection()
                current_user = g.current_user
                
                if self.is_professor(current_user):
                    user_id = current_user.id.iloc[0]
                    response, status_code = fs.return_salas_by_prof(engine, user_id)
                else:
                    response, status_code = fs.return_salas(engine)
    
                return response, status_code
    
            except SQLAlchemyError as e:
                print(f"SQLAlchemy Error: {str(e)}")
                return {'message': 'Internal server error'}, 500
            except Exception as e:
                print(f"An unexpected error occurred: {str(e)}")
                return {'message': 'Internal server error'}, 500
            finally:
                if engine:
                    engine.dispose()
                    
        def is_professor(self, user):
            return user.tipo.iloc[0] == 'professor'  
        
    @api.route('/removeSala')
    class removeSala(Resource):
        
       @token_required
       def post(self):
           engine = None
           try:
               engine = create_connection()
               args = request.get_json()
               current_user = g.current_user
               user_id = current_user.id.iloc[0]
               
               print(args)
               if not self.is_professor(current_user):
                   return {'message': 'Acesso não autorizado'}, 403
               
               sala_id = args.get('sala_id')
               retorno, status_code = fs.RemoverSala(engine, int(sala_id))
               
               return retorno, status_code  # Retorno e código de status
           
           except Exception as e:
               print(f"Erro ao remover sala: {str(e)}")
               return {'message': 'Erro interno do servidor'}, 500
           
           finally:
               if engine:
                   engine.dispose()
   
       def is_professor(self, user):
           return user.tipo.iloc[0] == 'professor'
       
    @api.route('/chatTutor')
    class ChatTutor(Resource):
        
        @token_required
        def post(self):
            engine = None
            try:
                engine = create_connection()
                args = request.get_json()
                current_user = g.current_user
                id_usuario = current_user.id.iloc[0]
                id_sala = args.get('id_sala')
                mensagem = args.get('mensagem')
                
                resp = ct.ChatTutor(engine, id_usuario, id_sala, mensagem)
                
                return resp
            except SQLAlchemyError as e:
               print(f"SQLAlchemy Error: {str(e)}")
               return {'message': 'Internal server error1'}, 500
            except Exception as e:
               print(f"Erro no ChatTutor: {str(e)}")
               return {'message': 'Internal server error2'}, 500
            
            finally:
                if engine:
                    engine.dispose()
                    
        @token_required
        def get(self):
            engine = None
            try:
                engine = create_connection()
                current_user = g.current_user
                args = request.args.to_dict()
                id_sala = args.get('id_sala','')
                id_user = current_user.id.iloc[0]
                
                if id_sala != '':                    
                    hist = ct.get_messages(engine, id_sala, id_user)
                    return hist
                else:
                    return {'message': 'Nenhuma sala foi passada'}, 480
               
    
            except SQLAlchemyError as e:
                print(f"SQLAlchemy Error: {str(e)}")
                return {'message': 'Internal server error1'}, 500
            except Exception as e:
                print(f"Erro no ChatTutor: {str(e)}")
                return {'message': 'Internal server error2'}, 500
            finally:
                if engine:
                    engine.dispose()
                        
               
                
                
            
            
            
  
    return app
