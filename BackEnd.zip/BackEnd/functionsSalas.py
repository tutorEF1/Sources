from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import json
import pandas as pd

def CriarSala(user_id, config, engine):
    try:
        query = text("""
                     INSERT INTO Salas
                     (id_professor, configSala)
                     VALUES (:user_id, :config)
                     """)
        
        engine.execute(query, user_id=user_id, config=json.dumps(config))
        
        return {'message': 'Sala criada com sucesso.'}, 201  
        
    except SQLAlchemyError as e:
        print(f"Erro ao criar sala: {str(e)}")
        return {'message': f"Erro ao criar sala: {str(e)}"}, 500

def RemoverSala(engine, sala_id):
    try:
        query = text("""
                    DELETE from Salas
                    WHERE id = :sala_id
                     """)
        
        engine.execute(query, sala_id=sala_id)
        
        return {'message': 'Sala removida com sucesso.'}, 201  
        
    except SQLAlchemyError as e:
        print(f"Erro ao deletar sala: {str(e)}")
        return {'message': f"Erro ao deletar sala: {str(e)}"}, 500


def return_salas(engine):
        try:
            
            salas = pd.read_sql_query( '''SELECT                                             
                                            usuarios.nome AS nome_professor,                                            
                                            salas.id AS id_sala,
                                            salas.configSala AS config_sala
                                        FROM 
                                            usuarios
                                        INNER JOIN 
                                            salas ON usuarios.id = salas.id_professor;
                                         ''', con=engine )
            
            return salas.to_dict(orient = 'records'), 201 
        
        except SQLAlchemyError as e:
            print(f"SQLAlchemy Error: {str(e)}")
            return {'message': 'Internal server error'}, 500
    
def return_salas_by_prof(engine, user_id):
    try:
        
        salas = pd.read_sql_query('''SELECT * from salas WHERE id_professor = %d''' %(int(user_id)), con=engine)
        
        return salas.to_dict(orient = 'records'), 201
    
    except SQLAlchemyError as e:
        print(f"SQLAlchemy Error: {str(e)}")
        return {'message': 'Internal server error'}, 500