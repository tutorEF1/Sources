from utils import get_key_gepeto
import requests
import json




def chamadaGEPETO(message):
    
    try:
        # message = 'Hello, is this working?'
        
        base = f"""
                Please responde the following message: {message}
                """
                
        messages = [
            
            {
                "role": "user",
                "content": base
            }
        ]

        url = 'https://api.openai.com/v1/chat/completions'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': get_key_gepeto(tipo='completo')
        }

        data = {
            'model': 'gpt-3.5-turbo',
            'messages': messages
        }
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        answer = response.json()['choices'][0]['message']['content']
        # print(answer)
        return answer
        
    except Exception as e:
        print('ERRO: ', str(e))