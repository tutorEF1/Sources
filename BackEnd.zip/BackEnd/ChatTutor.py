import openai
from utils import get_key_gepeto
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
import json
import pandas as pd
import time
from requests.exceptions import ReadTimeout
from datetime import datetime


openai.api_key = get_key_gepeto(tipo='curto')


def CreateContext(id_sala, engine):
    sala_config = getSalaConfig(engine, id_sala)

    if sala_config != 'NF':
        sala_json = json.loads(sala_config)

        area = sala_json.get('area')
        assunto = sala_json.get('assunto')
        caracteristica = sala_json.get('caracteristica')

        PromptControle = f"""
                            - Assuma o papel de um professor virtual extremamente didático e carismático  dando uma aula;
                            - Seu nome é Professor A.I.rton
                            - Área da aula: <<<{area}>>>;
                            - Assunto da aula: <<<{assunto}>>>;
                            - Responda apenas perguntas relacionadas à área e ao assunto que foram especificados;
                            - Se uma pergunta estiver fora do tema, sugira uma pergunta ao aluno, que esteja relacionada com o tema e com o assunto para que ele possa fazer;
                            - Ajuste seu vocabulário para um aluno de 8 anos;
                            - Caso o aluno ainda não tenha feito nenhuma pergunta relacionada, se apresente para ele;
                            - Característica do aluno: {caracteristica};
                            - Sempre respeite a área e o assunto marcados entre <<<>>>;                            
                        """
        return PromptControle
    else:
        return ''


def ChatTutor(engine, id_usuario, id_sala, mensagem):

    historico = get_messages(engine, id_sala, id_usuario)

    if not bool(historico):  # Caso o usuario não tenha nenhuma interação registrada
        context = CreateContext(id_sala, engine)
        insert_message(engine, id_sala, id_usuario, 'system', context)
        insert_message(engine, id_sala, id_usuario, 'user', mensagem)
        contexto = [{'role': 'system', 'content': context},
                    {'role': 'user', 'content':  mensagem}]

        resposta = get_completion_from_messages(contexto)
        insert_message(engine, id_sala, id_usuario, 'assistant', resposta)

        return resposta

    else:

        insert_message(engine, id_sala, id_usuario, 'user', mensagem)
        historico.append({'role': 'user', 'content':  mensagem})
        print(historico)
        resposta = get_completion_from_messages(historico)
        insert_message(engine, id_sala, id_usuario, 'assistant', resposta)

        return resposta


def insert_message(engine, id_sala, id_usuario, role, mensagem):

    try:
        query = text("""
                    INSERT INTO historico_conversa
                    (id_sala, id_usuario, role, content)
                    VALUES (:id_sala, :id_usuario, :role, :mensagem)
                    """)

        engine.execute(query, id_sala=id_sala,
                       id_usuario=id_usuario, role=role, mensagem=mensagem)

        return {'message': 'Message inserted successfully.'}, 201

    except SQLAlchemyError as e:
        print(f"Error inserting message: {str(e)}")
        return {'message': f"Error inserting message: {str(e)}"}, 500


def get_messages(engine, id_sala, id_user):
    try:
        messages_df = pd.read_sql_query("""
                                        SELECT role, content 
                                        FROM historico_conversa
                                        WHERE id_sala = %d
                                        AND id_usuario = %d
                                        ORDER BY data ASC
                                        """ % (int(id_sala), int(id_user)), con=engine)

        messages = messages_df.to_dict(orient='records')

        return messages

    except SQLAlchemyError as e:
        print(f"SQLAlchemy Error: {str(e)}")
        return {'message': 'Internal server error'}, 500

# %% Utils
def timeNOW():
    return datetime.now().strftime("%H:%M:%S")

def getSalaConfig(engine, id_sala):

    sala = pd.read_sql_query(
        '''SELECT configSala from salas WHERE id = %d''' % (int(id_sala)), con=engine)
    if not sala.empty:
        return sala.iloc[0].configSala
    else:
        return 'NF'

# %% Exemplos


prompt = "Olá voce esta funcionando?"

# O chat vai ser concatenado a este contexto
contexto = [{'role': 'system', 'content': """ 
             
             """}]


def get_completion(prompt, model="gpt-3.5-turbo", temperature=0):

    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=temperature,  # this is the degree of randomness of the model's output
    )
    return response.choices[0].message["content"]


def get_completion_from_messages(messages, temperature=1, model="gpt-3.5-turbo", max_retries=3, wait_time=30):
    for attempt in range(max_retries):
        try:
            response = openai.ChatCompletion.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=3000
            )
            return response.choices[0].message["content"]
        except (openai.error.OpenAIError, ReadTimeout) as e:
            # Handle specific exceptions here if needed
            if isinstance(e, openai.error.RateLimitError):
                # If rate limit error, you can get the number of seconds to wait from the error itself
                wait_time = e.retry_after
            print(f"Error encountered: {e}. Retrying in {wait_time} seconds.")
            time.sleep(wait_time)
    # If reached here, it means max_retries was exhausted
    raise Exception("Max retries reached. Could not fetch completion.")


def collect_messages(prompt):

    contexto.append({'role': 'user', 'content': f"{prompt}"})
    response = get_completion_from_messages(contexto)
    contexto.append({'role': 'assistant', 'content': f"{response}"})
    
#%% Dados TCC

#%%%% Perguntas
perguntas_LP_prod_text = ['Por que é importante fazer parágrafos no meu texto?',
                        'Como eu sei onde colocar vírgulas e pontos?',
                        'O que são verbos e por que eu preciso deles no meu texto?'
                        'Como faço para escrever uma história interessante?',
                        'Por que preciso revisar meu texto depois de escrever?',
                        'O que são rimas e como eu posso usá-las em meus textos?',
                        'Como faço para escrever uma carta para o meu amigo?',
                        'O que é um título e por que cada história precisa de um?',
                        'Como posso fazer minhas frases mais interessantes?',
                        'O que significa "descrição"e como posso usar isso para tornar minha história mais legal?']

perguntas_LP_leitura_e_interpr_text = ['Como eu sei o que o autor quis dizer com a história?',
                                    'O que eu faço se houver palavras que eu não conheço?',
                                    'Como posso lembrar o que aconteceu no início do livro quando eu chego ao final?',
                                    'Como as imagens no livro me ajudam a entender a história?',
                                    'Como posso imaginar os personagens e lugares na história?',
                                    'O que é um personagem principal e como eu o identifico?',
                                    'Por que algumas partes da história são mais importantes do que outras?',
                                    'O que significa "moral da história"e como eu a encontro?',
                                    'Por que algumas histórias me fazem sentir triste e outras me fazem sentir feliz?',
                                    'Como as histórias de diferentes lugares do mundo são diferentes das que estou acostumado a ler?']

perguntas_CN_caract_anim = ['Por que alguns animais têm penas e outros têm pele?',
                        'Como os animais sabem quando é hora de hibernar?',
                        'Por que alguns animais vivem na água e outros na terra?',
                        'O que faz um animal ser considerado um mamífero?',
                        'Por que alguns animais são tão pequenos e outros são enormes?',
                        'O que significa ser um animal noturno?',
                        'Por que alguns animais têm caudas longas?',
                        'Como os animais que vivem no frio se mantêm aquecidos?',
                        'Por que alguns animais têm tantas cores diferentes?',
                        'O que faz os insetos serem diferentes de outros animais?']

perguntas_CN_vert_e_invert = ['O que faz um animal ser vertebrado ou invertebrado?',
                        'Como posso dizer se um animal tem uma espinha dorsal só de olhar para ele?',
                        'Todos os animais que vivem na água são invertebrados?',
                        'Por que é importante para alguns animais ter uma espinha dorsal?',
                        'Existem animais invertebrados que vivem na terra?',
                        'Os animais invertebrados são sempre menores que os vertebrados?',
                        'Os insetos são vertebrados ou invertebrados?',
                        'Como a espinha dorsal ajuda os animais vertebrados?',
                        'Por que alguns animais não precisam de uma espinha dorsal para viver?',
                        'Qual é o maior animal invertebrado que existe?']


temperaturas = [0, 0.4, 0.8, 1.2, 1.6, 2]

salas_id_LP_prod_text = [1,4,5]
salas_id_LP_leitura_e_interpr_text = [6,7,8]
salas_id_CN_caract_anim = [9, 10, 11]
salas_id_CN_vert_e_invert = [12, 13, 14]

perfis = ["Aluno com Problemas de Atenção","Aluno com Dificuldade de Aprendizado", "Aluno Avançado"]

#%%%% Fazedor de pergunta CN vert invert
def fazedor_de_perguntas_CN_vert_e_invert():
    counter = 0
    respostas_final = pd.DataFrame()
    csv_filename = 'CN_vert_e_invert.csv'
    try:
        with open(csv_filename, 'r') as f:
            header_mode = False
    except FileNotFoundError:
        header_mode = True
    
    for pergunta in perguntas_CN_vert_e_invert:
        # if counter > 2 : break        
        for perfil in perfis:
            # if counter > 2 : break            
            for temp in temperaturas:
                # if counter > 2 : break
                
                PromptControle = f"""
                                - Assuma o papel de um professor virtual extremamente didático e carismático  dando uma aula;
                                - Seu nome é Professor A.I.rton
                                - Área da aula: <<<Ciências Naturais>>>;
                                - Assunto da aula: <<<Animais vertebrados e invertebrados>>>;
                                - Responda apenas perguntas relacionadas à área e ao assunto que foram especificados;
                                - Se uma pergunta estiver fora do tema, sugira uma pergunta ao aluno, que esteja relacionada com o tema e com o assunto para que ele possa fazer;
                                - Ajuste seu vocabulário para um aluno de 8 anos;
                                - Caso o aluno ainda não tenha feito nenhuma pergunta relacionada, se apresente para ele;
                                - Característica do aluno: {perfil};
                                - Sempre respeite a área e o assunto marcados entre <<<>>>;                            
                 
                            """
                counter = counter + 1      
                
                
                contexto_controladado = [{'role': 'system', 'content': PromptControle},
                                         {'role': 'user', 'content':  pergunta}]
                
                contexto_cru = [{'role': 'user', 'content':  pergunta}]
                print('Fazendo pergunta controlada', timeNOW())
                resposta_controlada = get_completion_from_messages(contexto_controladado, temperature = temp)
                print('recebido a resposta da pergunta controlada', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                print('Fazendo pergunta crua', timeNOW())
                resposta_crua = get_completion_from_messages(contexto_cru, temperature = temp)
                print('recebido a resposta da pergunta crua', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                data = {
                    'contador': counter,
                    'area':'Lingua Portuguesa',
                    'assunto':'Produção Textual',
                    'pergunta': pergunta,
                    'perfil': perfil,
                    'temperatura': temp,
                    'resposta_controlada':resposta_controlada,
                    'resposta_crua':resposta_crua,
                }
                # Append the data to the CSV directly after each iteration
                pd.DataFrame([data]).to_csv(csv_filename, mode='a', header=header_mode, index=False)
                
                # Ensure that header is only written once
                header_mode = False
               
                
                print(f"pergunta: {pergunta}, perfil: {perfil}, temp: {temp}, counter: {counter}")
             
    return pd.read_csv(csv_filename)

# cn_vert_e_invert = fazedor_de_perguntas_CN_vert_e_invert()


#%%%% Fazedor de pergunta LP PROD TEXT

def fazedor_de_perguntas_LP_prod_text():
    counter = 0
    respostas_final = pd.DataFrame()
    csv_filename = 'LP_prod_text.csv'
    try:
        with open(csv_filename, 'r') as f:
            header_mode = False
    except FileNotFoundError:
        header_mode = True
    
    for pergunta in perguntas_LP_prod_text:
        # if counter > 2 : break        
        for perfil in perfis:
            # if counter > 2 : break            
            for temp in temperaturas:
                # if counter > 2 : break
                
                PromptControle = f"""
                                - Assuma o papel de um professor virtual extremamente didático e carismático  dando uma aula;
                                - Seu nome é Professor A.I.rton
                                - Área da aula: <<<Lingua Portuguesa>>>;
                                - Assunto da aula: <<<Produção Textual>>>;
                                - Responda apenas perguntas relacionadas à área e ao assunto que foram especificados;
                                - Se uma pergunta estiver fora do tema, sugira uma pergunta ao aluno, que esteja relacionada com o tema e com o assunto para que ele possa fazer;
                                - Ajuste seu vocabulário para um aluno de 8 anos;
                                - Caso o aluno ainda não tenha feito nenhuma pergunta relacionada, se apresente para ele;
                                - Característica do aluno: {perfil};
                                - Sempre respeite a área e o assunto marcados entre <<<>>>;                            
                 
                            """
                counter = counter + 1      
                
                
                contexto_controladado = [{'role': 'system', 'content': PromptControle},
                                         {'role': 'user', 'content':  pergunta}]
                
                contexto_cru = [{'role': 'user', 'content':  pergunta}]
                print('Fazendo pergunta controlada', timeNOW())
                resposta_controlada = get_completion_from_messages(contexto_controladado, temperature = temp)
                print('recebido a resposta da pergunta controlada', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                print('Fazendo pergunta crua', timeNOW())
                resposta_crua = get_completion_from_messages(contexto_cru, temperature = temp)
                print('recebido a resposta da pergunta crua', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                data = {
                    'contador': counter,
                    'area':'Lingua Portuguesa',
                    'assunto':'Produção Textual',
                    'pergunta': pergunta,
                    'perfil': perfil,
                    'temperatura': temp,
                    'resposta_controlada':resposta_controlada,
                    'resposta_crua':resposta_crua,
                }
                # Append the data to the CSV directly after each iteration
                pd.DataFrame([data]).to_csv(csv_filename, mode='a', header=header_mode, index=False)
                
                # Ensure that header is only written once
                header_mode = False
               
                
                print(f"pergunta: {pergunta}, perfil: {perfil}, temp: {temp}, counter: {counter}")
             
    return pd.read_csv(csv_filename)
                
# LP_prod_text = fazedor_de_perguntas_LP_prod_text()               
        
#%%%% Fazedor de pergunta LP leitura_e_interpr
def fazedor_de_perguntas_LP_leitura_e_interpr():
    counter = 0
    respostas_final = pd.DataFrame()
    csv_filename = 'LP_leitura_e_interpr.csv'
    # Check if the file exists to determine the header mode.
    try:
        with open(csv_filename, 'r') as f:
            header_mode = False
    except FileNotFoundError:
        header_mode = True
    
    for pergunta in perguntas_LP_leitura_e_interpr_text:
        # if counter > 8: break
        for perfil in perfis:
            # if counter > 8: break
            for temp in temperaturas:
                # if counter > 8: break
                PromptControle = f"""
                                    - Assuma o papel de um professor virtual extremamente didático e carismático  dando uma aula;
                                    - Seu nome é Professor A.I.rton
                                    - Área da aula: <<<Lingua Portuguesa>>>;
                                    - Assunto da aula: <<<Leitura e Interpretação de Textos>>>;
                                    - Responda apenas perguntas relacionadas à área e ao assunto que foram especificados;
                                    - Se uma pergunta estiver fora do tema, sugira uma pergunta ao aluno, que esteja relacionada com o tema e com o assunto para que ele possa fazer;
                                    - Ajuste seu vocabulário para um aluno de 8 anos;
                                    - Caso o aluno ainda não tenha feito nenhuma pergunta relacionada, se apresente para ele;
                                    - Característica do aluno: {perfil};
                                    - Sempre respeite a área e o assunto marcados entre <<<>>>;                            
                 
                            """
                counter = counter + 1      
                
                
                contexto_controladado = [{'role': 'system', 'content': PromptControle},
                                         {'role': 'user', 'content':  pergunta}]
                
                contexto_cru = [{'role': 'user', 'content':  pergunta}]
                
                print('Fazendo pergunta controlada', timeNOW())
                resposta_controlada = get_completion_from_messages(contexto_controladado, temperature = temp)
                print('recebido a resposta da pergunta controlada', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                print('Fazendo pergunta crua', timeNOW())
                resposta_crua = get_completion_from_messages(contexto_cru, temperature = temp)
                print('recebido a resposta da pergunta crua', timeNOW())
                print('~~~~~~~DORMINDO~~~~~~~~~ ', timeNOW())
                time.sleep(30)
                print('----------ACORDANDO---------', timeNOW())
                data = {
                    'contador': counter,
                    'area':'Lingua Portuguesa',
                    'assunto':'Leitura e Interpretação de Textos',
                    'pergunta': pergunta,
                    'perfil': perfil,
                    'temperatura': temp,
                    'resposta_controlada':resposta_controlada,
                    'resposta_crua':resposta_crua,
                }
                # Append the data to the CSV directly after each iteration
                pd.DataFrame([data]).to_csv(csv_filename, mode='a', header=header_mode, index=False)
                
                # Ensure that header is only written once
                header_mode = False
                print(f"pergunta: {pergunta}, perfil: {perfil}, temp: {temp}, counter: {counter}")
               
          
    return pd.read_csv(csv_filename)

# LP_leitura_e_interpr = fazedor_de_perguntas_LP_leitura_e_interpr()
        
        
        
        

