import React, { useEffect, useState } from 'react';
import {Route, Routes, Navigate } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import CloneGPT from './components/CloneGPT';
import CriarSala from './components/CriarSala';
import ListarSalas from './components/ListarSalas';
import Sidebar from './components/Sidebar';
import LoginPage from './components/LoginPage';
import SaladeAula from './components/SaladeAula';
import './App.css';


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);

  const updateLoginStatus = (status) => {
    setIsLoggedIn(status);
    if (status) {
      setUser(JSON.parse(localStorage.getItem('usuario')));
    } else {
      setUser(null);
    }
  };
  

  useEffect(() => {
    const token = localStorage.getItem('token');
    
    if (token) {
      setIsLoggedIn(true);
      setUser(JSON.parse(localStorage.getItem('usuario')));
      // console.log('uuuuuuu', JSON.parse(localStorage.getItem('usuario')));
    }
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      {isLoggedIn && <Sidebar user={user}  updateLoginStatus={updateLoginStatus}/>}  {/* Conditionally render Sidebar */}
      <div className="content">
        <Routes>
          <Route path="/" element={isLoggedIn ? <LandingPage /> : <Navigate to="/login" />} index />
          <Route path="/login" element={<LoginPage updateLoginStatus={updateLoginStatus} />} /> 
          <Route path="/cloneGPT" element={<CloneGPT />} />
          <Route path="/CriarSala" element={<CriarSala  user={user}/>} />
          <Route path="/ListarSalas" element={<ListarSalas />} />
          <Route path="/SalaPage/:salaId" element={<SaladeAula/>} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
