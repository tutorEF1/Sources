function getToken() {
    const token = localStorage.getItem('token')
    if (token === null) {
        return ''
    } else {
        return token
    }
}


function getUser(){
    const user = localStorage.getItem('usuario')
    if (user === null) {
        return ''
    } else {
        return JSON.parse(user)
    }
}
export {getToken}