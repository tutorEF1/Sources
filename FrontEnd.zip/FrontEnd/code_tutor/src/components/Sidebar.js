import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Sidebar.css';

const Sidebar = ({ user, updateLoginStatus }) => {
  const location = useLocation();

  const logout = () => {
    localStorage.clear();
    updateLoginStatus(false)
    window.location.href = '/';
  };

  return (
    <nav className='sidebar'>
      {user ? <div className='user-card'>
        <h2>Olá, {user.nome}</h2>
        <p>{user.tipo}</p>
      </div> : null}
      <ul>
        {user.tipo === 'professor' ?
          <Link to="/cloneGPT" className='link'>
            <li className={location.pathname === "/cloneGPT" ? "active" : ""}>
              CloneGPT
            </li>
          </Link>
          : null}

        {user.tipo === 'professor' ?
          <Link to="/CriarSala" className='link'>
            <li className={location.pathname === "/CriarSala" ? "active" : ""}>
              Criar Sala
            </li>
          </Link>
          : null}

        {user.tipo === 'aluno' ?
          <Link to="/ListarSalas" className='link'>
            <li className={location.pathname === "/ListarSalas" ? "active" : ""}>
              Salas de Aula
            </li>
          </Link>
          : null}

      </ul>
      <button onClick={logout} className='logout-button'>Logout</button>
    </nav>
  );
};

export default Sidebar;