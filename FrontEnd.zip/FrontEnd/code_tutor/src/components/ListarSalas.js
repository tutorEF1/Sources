import React,{useEffect, useState} from 'react';
import api from '../services/api';
import { getToken } from '../utils/utils';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import {useNavigate} from 'react-router-dom'

const ListarSala = () => {
  const navigate = useNavigate();
  const [salas, setSalas] = useState([])

  useEffect(() => {
    ReturnSalas()
  }, [])

  const ReturnSalas = async () => {
    const resp = await api.get('/returnSalas', { headers: { 'x-api-key': getToken() } })
    console.log('salasTODAS', resp.data)
    setSalas(resp.data)
  }
  const goToSalaPage = (sala) => {
    console.log('sala',sala)
    if (sala) { // Check if 'sala' is defined
      navigate(`/SalaPage/${sala.id_sala}`);
    } else {
      console.error("Sala is undefined");
    }
  };
  return (
    <div>
      {salas.map((item, index) => (
          <Card key={index} style={{ margin: '20px', backgroundColor: 'lightcoral', borderRadius:10 }}>
            <div>
              <h3>{JSON.parse(item.config_sala).nome}</h3>
            </div>
            <CardContent style={{ flex: 1 }}>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Area: </p>
                <p>{JSON.parse(item.config_sala).area}</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Assunto: </p>
                <p>{JSON.parse(item.config_sala).assunto}</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Caracteristica: </p>
                <p>{JSON.parse(item.config_sala).caracteristica}</p>
              </div>

            </CardContent>
            <Button 
            variant="contained" 
            color="primary" 
            style={{ margin: '10px' }}
            onClick={() => goToSalaPage(item)}
            >Acessar Sala</Button>           
          </Card>
        ))}
    </div>
  );
};

export default ListarSala;
