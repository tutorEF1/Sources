import React, { useState } from 'react';
import api from '../services/api';
import './CloneGPT.css';

const CloneGPT = () => {
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e) => {
    setQuestion(e.target.value);
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setConversation([
      ...conversation,
      { type: 'user', text: question },
    ]);
    const response = await api.post('/chatbase', { pergunta: question });
    setConversation(prevConversation => [
      ...prevConversation,
      { type: 'gpt', text: response.data },
    ]);
    setQuestion(''); // Clear the question input box
    setIsLoading(false);
  };

  return (
    <div className='chat-container'>
      <h1>CloneGPT</h1>
      <div className='chat-box'>
        {conversation.map((item, index) => (
          <div key={index} className={item.type === 'user' ? 'user-message' : 'gpt-message'}>
            <span className='message-text'>{item.text}</span>
          </div>
        ))}
      </div>
      <div className='input-container'>
        <input
          className='input-box'
          type="text"
          value={question}
          onChange={handleInputChange}
          placeholder="Faça a sua pergunta aqui..."
        />
        <button className='send-button' onClick={handleSubmit} disabled={isLoading}>{isLoading ? 'Enviando...' : 'Enviar'}</button>
      </div>
    </div>
  );
};

export default CloneGPT;