// Import dependencies
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate
import api from '../services/api';
import './LoginPage.css';

// Use camelCase for variable and function names
const LoginPage = ({updateLoginStatus}) => {
    const [login, setLogin] = useState('');
    const [senha, setSenha] = useState('');
    const navigate = useNavigate(); // Initialize useNavigate

    const handleLogin = async (e) => {
        e.preventDefault();

        // Validate if fields are not empty
        if (!login.trim() || !senha.trim()) {
            console.log("Both fields are required");
            return;
        }
        
        try {
            const response = await api.post('/login', { 'login': login, 'senha': senha });
            
            if (response.status === 200) {
                let token = response.data.token;
                let usuario = response.data.user_info;
                localStorage.setItem('token', token);  // Store token in localStorage
                localStorage.setItem('usuario', JSON.stringify(usuario))
                updateLoginStatus(true);
                navigate("/");  // Use navigate instead of history.push
            }
        } catch (e) {
            console.log(e.message);
        }
    };

    return (
        <div className='login-page'>
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <input type='text' value={login} onChange={(e) => setLogin(e.target.value)} placeholder='Login' />
                <input type='password' value={senha} onChange={(e) => setSenha(e.target.value)} placeholder='Senha' />
                <button type='submit'>Login</button>
            </form>
        </div>
    );
};

export default LoginPage;
