
import React from 'react';

const LandingPage = () => {
  return (
    <div className="landing-page">
      <h1>Welcome to My App</h1>
      <p>Click on the sidebar to navigate.</p>
    </div>
  );
};

export default LandingPage;
