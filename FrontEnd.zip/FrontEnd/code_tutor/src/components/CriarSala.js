import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { getToken } from '../utils/utils';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import {useNavigate} from 'react-router-dom'

const CriarSala = ({ user }) => {
  const navigate = useNavigate();
  const [nome, setNome] = useState('');
  const [area, setArea] = useState('');
  const [assunto, setAssunto] = useState('');
  const [caracteristica, setCaracteristica] = useState('');

  const [areaOptions, setAreaOptions] = useState(['Lingua Portuguesa', 'Ciências Naturais', 'História', 'Geografia']);
  const [assuntoOptions, setAssuntoOptions] = useState({
    'Lingua Portuguesa': ['Produção Textual', 'Leitura e Interpretação de Textos'],
    'Ciências Naturais': ['Características dos animais', 'Animais vertebrados e invertebrados'],
    'História': ['Formas de trabalho na cidade e no campo', 'Fontes históricas'],
    'Geografia': ['Consumo de água: refletir para economizar', 'O que é município?'],
  });
  const [caracteristicaOptions, setCaracteristicaOptions] = useState(['Aluno com Dificuldade de Aprendizado', 'Aluno Avançado', 'Aluno com Problemas de Atenção']);

  const [salas, setSalas] = useState([]);
  const [criacao, setCriacao] = useState(false)

  useEffect(() => {
    ReturnSalas()
  }, [criacao])

  const ReturnSalas = async () => {
    const resp = await api.get('/returnSalas', { headers: { 'x-api-key': getToken() } })
    console.log('salas', resp.data)
    setSalas(resp.data)
  }

  const HandleCriar = async () => {
    if ([''].includes(nome, area, assunto, caracteristica)) {
      alert('Os campos Nome, Area e Assunto são obrigatórios')
      return
    }
    setCriacao(!criacao)
    const resp = await api.post('/criarSala', {
      "nome": nome,
      "area": area,
      "assunto": assunto,
      "caracteristica": caracteristica
    }, { headers: { 'x-api-key': getToken() } })
    if (resp.status === 201) {
      alert(resp.data.message)
      setCriacao(!criacao)

      HandleClearStates()
    }

  }

  const HandleClearStates = () => {
    setArea('')
    setNome('')
    setAssunto('')
    setCaracteristica('')
  }

  const HandleRemove = async (sala_id) => {
    const resp = await api.post('/removeSala', {
      "sala_id": sala_id
    }, { headers: { 'x-api-key': getToken() } })
    console.log('asdasdremove', resp)
    if (resp.status === 201) {
      alert(resp.data.message)
      setCriacao(!criacao)
    }
  }

  const goToSalaPage = (sala) => {
    console.log('sala',sala)
    if (sala) { // Check if 'sala' is defined
      navigate(`/SalaPage/${sala.id}`);
    } else {
      console.error("Sala is undefined");
    }
  };

  return (
    <div className='panels'>
      <div className='input-panel'>
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <h3>Criar Sala</h3>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <TextField
            type='text'
            value={nome} onChange={(e) => setNome(e.target.value)}
            placeholder='Nome'
            style={{ padding: 10, width: '80%', backgroundColor: '#fff', borderRadius: '4px' }}
          />
          <Autocomplete
            options={areaOptions}
            getOptionLabel={(option) => option}
            value={area}  // Use the existing 'area' state
            onChange={(event, newValue) => {
              setArea(newValue);  // Update the 'area' state
            }}
            style={{ padding: 10, width: '80%', }}
            renderInput={(params) => <TextField {...params} label="Area" variant="outlined" style={{ backgroundColor: 'white' }} />}
          />
          <Autocomplete
            options={area ? assuntoOptions[area] : []}
            getOptionLabel={(option) => option}
            style={{ padding: 10, width: '80%', }}
            renderInput={(params) => <TextField {...params} label="Assunto" variant="outlined" style={{ backgroundColor: 'white' }} />}
            onChange={(event, newValue) => {
              setAssunto(newValue);
            }}
          />
          <Autocomplete
            options={caracteristicaOptions}
            getOptionLabel={(option) => option}
            style={{ padding: 10, width: '80%', }}
            renderInput={(params) => <TextField {...params} label="Caracteristica" variant="outlined" style={{ backgroundColor: 'white' }} />}
            onChange={(event, newValue) => {
              setCaracteristica(newValue);
            }}
          />
          <Button variant="contained" color="primary" onClick={() => HandleCriar()}>Criar Sala</Button>
        </div>

      </div>
      <div className='salas-panel'>
        <p>Minhas Salas</p>
        {salas.map((item, index) => (
          <Card key={index} style={{ marginBottom: '20px', backgroundColor: 'lightcyan' }}>
            <div>
              <h3>{JSON.parse(item.configSala).nome}</h3>
            </div>
            <CardContent style={{ flex: 1 }}>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Area: </p>
                <p>{JSON.parse(item.configSala).area}</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Assunto: </p>
                <p>{JSON.parse(item.configSala).assunto}</p>
              </div>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                <p>Caracteristica: </p>
                <p>{JSON.parse(item.configSala).caracteristica}</p>
              </div>

            </CardContent>
            <Button variant="contained" color="primary" onClick={() => goToSalaPage(item)} style={{ margin: '10px' }}>Acessar Sala</Button>
            <Button variant="contained" color="primary" onClick={() => HandleRemove(item.id)} style={{ margin: '10px' }}>removerSala</Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CriarSala;