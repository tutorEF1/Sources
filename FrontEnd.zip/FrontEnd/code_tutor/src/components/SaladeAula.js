import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import { getToken } from '../utils/utils';
import './SaladeAula.css';

const Message = ({ role, content }) => {
    const messageClass = role === 'user' ? 'message-user' : role === 'assistant' ? 'message-assistant' : 'message-system';
    return (
        <div className={`message ${messageClass}`}>
            <p>{content}</p>
        </div>
    );
};

const SaladeAula = ({ }) => {
    const { salaId } = useParams();
    const [historicoConversa, setHistoricoConversa] = useState([])
    const [mensagem, setMensagem] = useState('')
    const [resposta, setResposta] = useState('')

    useEffect(() => {

        getHistorico()

    }, [salaId]);
    
    useEffect(() => {

        getHistorico()

    }, [resposta]);

    const getHistorico = async () => {
        /**
         * Função para buscar todo o historico da conversa
         */
        const resp = await api.get('/chatTutor', { params: { 'id_sala': salaId }, headers: { 'x-api-key': getToken() } })
        setHistoricoConversa(resp.data)
    }

    const handleSendMessage = async (e) => {

        if (mensagem === '') {
            alert('Favor inserir um mensagem')
            return
        }
        e.preventDefault();
        const resp = await api.post('/chatTutor', { 'id_sala': salaId, 'mensagem': mensagem },{ headers: { 'x-api-key': getToken() } })
        setResposta(resp.data)
    };


    return (
        <div className="chat-container">
            <div className="chat-history">
                {historicoConversa.map((message, index) => (
                    message.role !== 'system' ?
                        <Message key={index} role={message.role} content={message.content} />
                    : null
                ))}
            </div>
            <div className="chat-input">
                <form onSubmit={handleSendMessage}>
                    <input type="text" value={mensagem} onChange={(e) => setMensagem(e.target.value)} />
                    <button type="submit">Enviar</button>
                </form>
            </div>
        </div>
    );
};

const styles = {
    message: {
        padding: '10px',
        margin: '5px',
        borderRadius: '5px',
    },
    'message-user': {
        backgroundColor: '#f1f1f1',
    },
    'message-assistant': {
        backgroundColor: '#d1f5d5',
    },
    'message-system': {
        backgroundColor: '#f5d5d5',
    },
};

export default SaladeAula;
